export class Scheme {
    constructor(
        public ledgerId?: string,
        public ledgerNature?: string,
        public ledgerName?: string,
        public ledgerType?: string,
        public createdBy?: string,
        public updatedBy?: string,
        public createdAt?: Date,
        public updatedAt?: Date,       
    ) {}
}