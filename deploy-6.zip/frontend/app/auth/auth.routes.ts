import { Route } from '@angular/router';
import { CanActivateViaAuthGuard } from './can.activate.via.auth.guard';
import { AddNewMemberComponent } from '../member/add.new.member.component';

export const AUTH_ROUTES: Route = [
    // { path: '/member/new', component: AddNewMemberComponent }
]