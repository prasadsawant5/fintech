module.exports = {
    mongoUri: 'mongodb://prasadsawant5:password@ds155028.mlab.com:55028/fintech',
    secret: 'PGEYpT7akx08V8N8QNkRySXVCIPQtQAabqnjMkUo0SLvAy1d1ZqfbeFBMfJobMdpBffDs32umRu1vAcAq6cqJ6PB7iDU8WiL8s91'
}